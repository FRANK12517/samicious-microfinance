' ═══════════════════════════════════════════════════════════════════════════════
' SAMCIOUS MICROFINANCE v3 — COMPLETE VBA PACKAGE
' Agent-Manager System  |  Ghana MFI Standard  |  10 Agent Dashboards
' ═══════════════════════════════════════════════════════════════════════════════
'
' INSTALLATION (10 minutes):
'   1. Open SAMCIOUS_MFI_v3.xlsm in Excel Desktop (File > Open)
'   2. Press Alt+F11 to open VBA Editor
'   3. In the left panel, click "ThisWorkbook" → paste MODULE A
'   4. Insert > Module for each of modules B–H, name each as shown
'   5. Close VBA Editor, Save (Ctrl+S), close and re-open
'   6. On first open, a setup dialog will appear — follow it
'
' DEFAULT MANAGER PASSWORD: SAMCIOUS_MANAGER_2026
' DEFAULT AGENT CODES:  AGT010000 through AGT100000 (change in SETTINGS)
' ═══════════════════════════════════════════════════════════════════════════════


' ═══════════════════════════════════════════════════════════════════════════════
' MODULE A — Paste into: ThisWorkbook
' ═══════════════════════════════════════════════════════════════════════════════
Option Explicit

Private Sub Workbook_Open()
    On Error GoTo OpenErr
    Application.WindowState = xlMaximized
    Application.ScreenUpdating = False
    Call modV3Admin.InitSystemV3
    Sheets("MANAGER_DASHBOARD").Activate
    Application.StatusBar = "SAMCIOUS MFI v3  |  Ready  |  " & Format(Now(), "DD MMM YYYY HH:MM")
    Application.ScreenUpdating = True
    Exit Sub
OpenErr:
    MsgBox "Startup warning: " & Err.Description, vbExclamation, "SAMCIOUS v3"
End Sub

Private Sub Workbook_BeforeClose(Cancel As Boolean)
    On Error Resume Next
    Call modV3AutoLock.CancelAllTimers
    Call modV3Admin.LockAllSheets
    Application.StatusBar = False
End Sub

Private Sub Workbook_SheetChange(ByVal Sh As Object, ByVal Target As Range)
    On Error Resume Next
    ' Protect system sheets from direct editing
    Dim sysSheets As String
    sysSheets = "AGENT_DATABASE,AdminSettings,Config,AuditLog"
    If InStr(sysSheets, Sh.Name) > 0 Then
        Application.EnableEvents = False
        Application.Undo
        Application.EnableEvents = True
        Exit Sub
    End If
    ' Reset inactivity timer on any change
    Call modV3AutoLock.ResetAgentTimer(Sh.Name)
End Sub

Private Sub Workbook_SheetSelectionChange(ByVal Sh As Object, ByVal Target As Range)
    On Error Resume Next
    ' Block direct navigation to admin-only sheets
    If Sh.Name = "AdminSettings" Or Sh.Name = "SETTINGS" Then
        If Not modV3Admin.IsManager() Then
            Sheets("MANAGER_DASHBOARD").Activate
            Exit Sub
        End If
    End If
    Call modV3AutoLock.ResetAgentTimer(Sh.Name)
End Sub


' ═══════════════════════════════════════════════════════════════════════════════
' MODULE B — Name module: modV3Admin
' Manager Authentication, Sheet Protection, Agent Management
' ═══════════════════════════════════════════════════════════════════════════════
Option Explicit

Private Const MGR_PW       As String = "SAMCIOUS_MANAGER_2026"
Private Const SHEET_PW     As String = "SAMCIOUS_SH_2026"
Private Const SETTINGS_SH  As String = "SETTINGS"
Private Const AGDB_SH      As String = "AGENT_DATABASE"
Private Const AUDIT_SH     As String = "AuditLog"
Private Const CONFIG_SH    As String = "Config"

Public Sub InitSystemV3()
    On Error Resume Next
    Application.Calculation = xlCalculationAutomatic

    ' Make SETTINGS very hidden from agents
    Sheets(SETTINGS_SH).Visible = xlSheetVeryHidden

    ' Ensure AGENT_DATABASE has headers
    Dim agWS As Worksheet: Set agWS = Sheets(AGDB_SH)
    agWS.Visible = xlSheetVeryHidden
    If agWS.Cells(1, 1).Value = "" Then
        Dim hdrs As Variant
        hdrs = Array("Timestamp", "Agent", "CustomerName", "AccountNo", "Phone",
                     "TxnType", "Amount", "InterestRate", "TotalPayable", "Status",
                     "Reason", "LoanID", "ApprovedBy")
        Dim i As Integer
        For i = 0 To UBound(hdrs)
            agWS.Cells(1, i + 1).Value = hdrs(i)
        Next i
    End If

    Call WriteAuditV3("SYSTEM START", "v3 Initialized", "System", "INFO")
End Sub

Public Function IsManager() As Boolean
    Dim pw As String
    pw = InputBox("Enter Manager Password:", "SAMCIOUS — Manager Authentication")
    If pw = MGR_PW Then
        IsManager = True
        Call WriteAuditV3("MANAGER LOGIN", Application.UserName, "System", "SUCCESS")
    Else
        IsManager = False
        If pw <> "" Then
            MsgBox "Incorrect password. Access denied.", vbCritical, "SAMCIOUS"
            Call WriteAuditV3("MANAGER LOGIN FAIL", Application.UserName, "System", "DENIED")
        End If
    End If
End Function

Public Function AuthenticateAgent(agentNum As Integer) As Boolean
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = Sheets(SETTINGS_SH)
    If ws Is Nothing Then AuthenticateAgent = False: Exit Function

    ws.Visible = xlSheetVisible
    Dim storedCode As String
    storedCode = Trim(ws.Cells(3 + agentNum, 4).Value) ' Col D, row 4+agent
    ws.Visible = xlSheetVeryHidden

    If storedCode = "" Then
        MsgBox "Agent " & agentNum & " has no code assigned. Contact your Manager.", _
               vbExclamation, "SAMCIOUS — Access Denied"
        AuthenticateAgent = False
        Exit Function
    End If

    ' Check agent status
    ws.Visible = xlSheetVisible
    Dim status As String
    status = Trim(ws.Cells(3 + agentNum, 6).Value) ' Col F = Status
    ws.Visible = xlSheetVeryHidden

    If UCase(status) <> "ACTIVE" Then
        MsgBox "Agent " & agentNum & " is DEACTIVATED. Contact your Manager.", _
               vbCritical, "SAMCIOUS"
        AuthenticateAgent = False
        Exit Function
    End If

    Dim entered As String
    entered = Trim(InputBox("Agent " & agentNum & " — Enter your unique code:", _
                            "SAMCIOUS — Agent Authentication"))
    If entered = "" Then AuthenticateAgent = False: Exit Function

    If entered = storedCode Then
        AuthenticateAgent = True
        Call WriteAuditV3("AGENT LOGIN", "Agent " & agentNum, "AGENT_" & agentNum, "SUCCESS")
    Else
        MsgBox "Invalid code. Contact your Manager.", vbCritical, "SAMCIOUS"
        Call WriteAuditV3("AGENT LOGIN FAIL", "Agent " & agentNum, "AGENT_" & agentNum, "DENIED")
        AuthenticateAgent = False
    End If
End Function

Public Sub LockAllSheets()
    On Error Resume Next
    Dim protected_sheets As Variant
    protected_sheets = Array("Members", "Transactions", "Loans", "Pending_Loans",
                             "Int_Repayments", "Repayment_Log", AGDB_SH)
    Dim s As Variant
    For Each s In protected_sheets
        Dim ws As Worksheet
        Set ws = Nothing
        Set ws = Sheets(CStr(s))
        If Not ws Is Nothing Then
            ws.Protect Password:=SHEET_PW, UserInterfaceOnly:=False, _
                AllowFiltering:=True, AllowSorting:=False
        End If
    Next s
    Sheets(SETTINGS_SH).Visible = xlSheetVeryHidden
    Sheets(AGDB_SH).Visible = xlSheetVeryHidden
End Sub

Public Sub UnlockSheets()
    On Error Resume Next
    Dim protected_sheets As Variant
    protected_sheets = Array("Members", "Transactions", "Loans", "Pending_Loans",
                             "Int_Repayments", "Repayment_Log", AGDB_SH)
    Dim s As Variant
    For Each s In protected_sheets
        Dim ws As Worksheet
        Set ws = Nothing
        Set ws = Sheets(CStr(s))
        If Not ws Is Nothing Then ws.Unprotect Password:=SHEET_PW
    Next s
End Sub

' ── Agent Code Management ────────────────────────────────────────────────────

Public Sub GenerateAgentCode()
    If Not IsManager() Then Exit Sub
    Dim ws As Worksheet
    ws = GetSettingsSheet()
    If ws Is Nothing Then MsgBox "Settings not accessible.", vbCritical: Exit Sub

    Dim agNum As String
    agNum = Trim(InputBox("Enter Agent Number (1-10):", "Generate Agent Code"))
    If Not IsNumeric(agNum) Then Exit Sub
    Dim n As Integer: n = CInt(agNum)
    If n < 1 Or n > 10 Then MsgBox "Invalid agent number.", vbExclamation: Exit Sub

    ' Generate unique 8-char code
    Dim newCode As String
    newCode = "AGT" & Format(n, "00") & Format(Int(Rnd() * 9000) + 1000, "0000")

    ws.Cells(3 + n, 4).Value = newCode
    ReleaseSettingsSheet ws

    MsgBox "✅ New code for Agent " & n & ":" & vbCrLf & vbCrLf & _
           "CODE: " & newCode & vbCrLf & vbCrLf & _
           "Share this code ONLY with Agent " & n, vbInformation, "SAMCIOUS — Agent Code"
    Call WriteAuditV3("CODE GENERATED", "Agent " & n & " | " & newCode, SETTINGS_SH, "SUCCESS")
End Sub

Public Sub SetAgentName()
    If Not IsManager() Then Exit Sub
    Dim ws As Worksheet
    Set ws = GetSettingsSheet()
    If ws Is Nothing Then Exit Sub

    Dim agNum As String
    agNum = Trim(InputBox("Agent Number (1-10):", "Set Agent Name"))
    If Not IsNumeric(agNum) Then ReleaseSettingsSheet ws: Exit Sub
    Dim n As Integer: n = CInt(agNum)
    If n < 1 Or n > 10 Then ReleaseSettingsSheet ws: Exit Sub

    Dim name_ As String
    name_ = Trim(InputBox("Enter name for Agent " & n & ":", "Set Agent Name"))
    If name_ = "" Then ReleaseSettingsSheet ws: Exit Sub

    ws.Cells(3 + n, 5).Value = name_
    ReleaseSettingsSheet ws
    MsgBox "Agent " & n & " name set to: " & name_, vbInformation, "SAMCIOUS"
End Sub

Public Sub ActivateAgent()
    If Not IsManager() Then Exit Sub
    Dim ws As Worksheet: Set ws = GetSettingsSheet()
    If ws Is Nothing Then Exit Sub
    Dim agNum As String: agNum = Trim(InputBox("Agent Number to ACTIVATE (1-10):", "Activate Agent"))
    If IsNumeric(agNum) Then
        Dim n As Integer: n = CInt(agNum)
        If n >= 1 And n <= 10 Then
            ws.Cells(3 + n, 6).Value = "ACTIVE"
            Call WriteAuditV3("AGENT ACTIVATED", "Agent " & n, SETTINGS_SH, "SUCCESS")
            MsgBox "Agent " & n & " is now ACTIVE.", vbInformation
        End If
    End If
    ReleaseSettingsSheet ws
End Sub

Public Sub DeactivateAgent()
    If Not IsManager() Then Exit Sub
    Dim ws As Worksheet: Set ws = GetSettingsSheet()
    If ws Is Nothing Then Exit Sub
    Dim agNum As String: agNum = Trim(InputBox("Agent Number to DEACTIVATE (1-10):", "Deactivate Agent"))
    If IsNumeric(agNum) Then
        Dim n As Integer: n = CInt(agNum)
        If n >= 1 And n <= 10 Then
            ws.Cells(3 + n, 6).Value = "INACTIVE"
            Call WriteAuditV3("AGENT DEACTIVATED", "Agent " & n, SETTINGS_SH, "WARNING")
            MsgBox "Agent " & n & " has been DEACTIVATED.", vbInformation
        End If
    End If
    ReleaseSettingsSheet ws
End Sub

Public Sub RevokeAgentAccess()
    If Not IsManager() Then Exit Sub
    Dim ws As Worksheet: Set ws = GetSettingsSheet()
    If ws Is Nothing Then Exit Sub
    Dim agNum As String: agNum = Trim(InputBox("Agent Number to REVOKE (1-10):", "Revoke Access"))
    If IsNumeric(agNum) Then
        Dim n As Integer: n = CInt(agNum)
        If n >= 1 And n <= 10 Then
            ws.Cells(3 + n, 4).Value = "REVOKED_" & Format(Now(), "YYYYMMDD")
            ws.Cells(3 + n, 6).Value = "REVOKED"
            Call WriteAuditV3("ACCESS REVOKED", "Agent " & n, SETTINGS_SH, "DENIED")
            MsgBox "Agent " & n & " access has been REVOKED.", vbInformation
        End If
    End If
    ReleaseSettingsSheet ws
End Sub

Private Function GetSettingsSheet() As Worksheet
    On Error Resume Next
    Dim ws As Worksheet: Set ws = Sheets(SETTINGS_SH)
    If Not ws Is Nothing Then ws.Visible = xlSheetVisible
    Set GetSettingsSheet = ws
End Function

Private Sub ReleaseSettingsSheet(ws As Worksheet)
    On Error Resume Next
    ws.Visible = xlSheetVeryHidden
End Sub

Public Sub WriteAuditV3(action As String, details As String, shName As String, status As String)
    On Error Resume Next
    Dim logWS As Worksheet: Set logWS = Sheets(AUDIT_SH)
    If logWS Is Nothing Then Exit Sub
    logWS.Unprotect Password:=SHEET_PW
    Dim nRow As Long
    nRow = logWS.Cells(logWS.Rows.Count, 1).End(xlUp).Row + 1
    If nRow < 2 Then nRow = 2
    With logWS
        .Cells(nRow, 1).Value = Format(Now(), "YYYY-MM-DD HH:MM:SS")
        .Cells(nRow, 2).Value = Application.UserName
        .Cells(nRow, 3).Value = Environ("USERNAME")
        .Cells(nRow, 4).Value = action
        .Cells(nRow, 5).Value = shName
        .Cells(nRow, 6).Value = status
        .Cells(nRow, 7).Value = details
        Select Case UCase(status)
            Case "SUCCESS":  .Cells(nRow, 6).Interior.Color = RGB(200, 230, 201)
            Case "DENIED":   .Cells(nRow, 6).Interior.Color = RGB(255, 205, 210)
            Case "WARNING":  .Cells(nRow, 6).Interior.Color = RGB(255, 224, 130)
            Case Else:       .Cells(nRow, 6).Interior.Color = RGB(227, 242, 253)
        End Select
    End With
    logWS.Protect Password:=SHEET_PW
End Sub


' ═══════════════════════════════════════════════════════════════════════════════
' MODULE C — Name module: modV3AutoLock
' 15-Minute Inactivity Auto-Lock per Agent Dashboard
' ═══════════════════════════════════════════════════════════════════════════════
Option Explicit

Private Const LOCK_MINUTES As Integer = 15
' Session flags (True = unlocked)
Public Agent1Unlocked  As Boolean
Public Agent2Unlocked  As Boolean
Public Agent3Unlocked  As Boolean
Public Agent4Unlocked  As Boolean
Public Agent5Unlocked  As Boolean
Public Agent6Unlocked  As Boolean
Public Agent7Unlocked  As Boolean
Public Agent8Unlocked  As Boolean
Public Agent9Unlocked  As Boolean
Public Agent10Unlocked As Boolean

' Next lock times
Private NextLock1  As Date, NextLock2  As Date, NextLock3  As Date
Private NextLock4  As Date, NextLock5  As Date, NextLock6  As Date
Private NextLock7  As Date, NextLock8  As Date, NextLock9  As Date
Private NextLock10 As Date

Public Function IsAgentUnlocked(agentNum As Integer) As Boolean
    Select Case agentNum
        Case 1:  IsAgentUnlocked = Agent1Unlocked
        Case 2:  IsAgentUnlocked = Agent2Unlocked
        Case 3:  IsAgentUnlocked = Agent3Unlocked
        Case 4:  IsAgentUnlocked = Agent4Unlocked
        Case 5:  IsAgentUnlocked = Agent5Unlocked
        Case 6:  IsAgentUnlocked = Agent6Unlocked
        Case 7:  IsAgentUnlocked = Agent7Unlocked
        Case 8:  IsAgentUnlocked = Agent8Unlocked
        Case 9:  IsAgentUnlocked = Agent9Unlocked
        Case 10: IsAgentUnlocked = Agent10Unlocked
        Case Else: IsAgentUnlocked = False
    End Select
End Function

Public Sub UnlockAgent(agentNum As Integer)
    Select Case agentNum
        Case 1:  Agent1Unlocked  = True: NextLock1  = Now + TimeValue("00:15:00")
        Case 2:  Agent2Unlocked  = True: NextLock2  = Now + TimeValue("00:15:00")
        Case 3:  Agent3Unlocked  = True: NextLock3  = Now + TimeValue("00:15:00")
        Case 4:  Agent4Unlocked  = True: NextLock4  = Now + TimeValue("00:15:00")
        Case 5:  Agent5Unlocked  = True: NextLock5  = Now + TimeValue("00:15:00")
        Case 6:  Agent6Unlocked  = True: NextLock6  = Now + TimeValue("00:15:00")
        Case 7:  Agent7Unlocked  = True: NextLock7  = Now + TimeValue("00:15:00")
        Case 8:  Agent8Unlocked  = True: NextLock8  = Now + TimeValue("00:15:00")
        Case 9:  Agent9Unlocked  = True: NextLock9  = Now + TimeValue("00:15:00")
        Case 10: Agent10Unlocked = True: NextLock10 = Now + TimeValue("00:15:00")
    End Select
    ' Schedule auto-lock
    Application.OnTime Now + TimeValue("00:15:00"), "modV3AutoLock.AutoLockAgent" & agentNum
End Sub

Public Sub LockAgent(agentNum As Integer)
    Select Case agentNum
        Case 1:  Agent1Unlocked  = False
        Case 2:  Agent2Unlocked  = False
        Case 3:  Agent3Unlocked  = False
        Case 4:  Agent4Unlocked  = False
        Case 5:  Agent5Unlocked  = False
        Case 6:  Agent6Unlocked  = False
        Case 7:  Agent7Unlocked  = False
        Case 8:  Agent8Unlocked  = False
        Case 9:  Agent9Unlocked  = False
        Case 10: Agent10Unlocked = False
    End Select
    ' Update status cell in agent sheet
    On Error Resume Next
    Dim ws As Worksheet: Set ws = Sheets("AGENT_" & agentNum)
    If Not ws Is Nothing Then
        ws.Range("I2").Value = "🔒  LOCKED — Click UNLOCK to begin"
        ws.Range("I2").Interior.Color = RGB(192, 57, 43)
        ws.Range("I2").Font.Color = RGB(255, 255, 255)
    End If
End Sub

Public Sub ResetAgentTimer(shName As String)
    On Error Resume Next
    Dim n As Integer
    If Left(shName, 6) = "AGENT_" Then
        n = CInt(Mid(shName, 7))
        If n >= 1 And n <= 10 Then
            If IsAgentUnlocked(n) Then Call UnlockAgent(n)
        End If
    End If
End Sub

Public Sub CancelAllTimers()
    On Error Resume Next
    Dim i As Integer
    For i = 1 To 10
        Application.OnTime Now + TimeValue("00:15:00"), _
            "modV3AutoLock.AutoLockAgent" & i, , False
    Next i
End Sub

' Individual auto-lock procedures (called by OnTime)
Public Sub AutoLockAgent1():  Call LockAgent(1):  End Sub
Public Sub AutoLockAgent2():  Call LockAgent(2):  End Sub
Public Sub AutoLockAgent3():  Call LockAgent(3):  End Sub
Public Sub AutoLockAgent4():  Call LockAgent(4):  End Sub
Public Sub AutoLockAgent5():  Call LockAgent(5):  End Sub
Public Sub AutoLockAgent6():  Call LockAgent(6):  End Sub
Public Sub AutoLockAgent7():  Call LockAgent(7):  End Sub
Public Sub AutoLockAgent8():  Call LockAgent(8):  End Sub
Public Sub AutoLockAgent9():  Call LockAgent(9):  End Sub
Public Sub AutoLockAgent10(): Call LockAgent(10): End Sub


' ═══════════════════════════════════════════════════════════════════════════════
' MODULE D — Name module: modV3Agent
' Agent Dashboard Actions: Unlock, Savings, Withdrawal, Loan Request, Registration
' ═══════════════════════════════════════════════════════════════════════════════
Option Explicit

' ── UNLOCK ───────────────────────────────────────────────────────────────────
Public Sub UnlockDashboard()
    Dim ws As Worksheet: Set ws = ActiveSheet
    If Left(ws.Name, 6) <> "AGENT_" Then
        MsgBox "Please navigate to your Agent Dashboard first.", vbExclamation
        Exit Sub
    End If
    Dim agentNum As Integer: agentNum = CInt(Mid(ws.Name, 7))

    If modV3AutoLock.IsAgentUnlocked(agentNum) Then
        MsgBox "Dashboard already unlocked. Session active for 15 minutes.", vbInformation
        Exit Sub
    End If

    If modV3Admin.AuthenticateAgent(agentNum) Then
        Call modV3AutoLock.UnlockAgent(agentNum)
        ' Update status bar in sheet
        ws.Range("I2").Value = "✅  UNLOCKED — Session active (15 min)"
        ws.Range("I2").Interior.Color = RGB(30, 107, 58)
        ws.Range("I2").Font.Color = RGB(255, 255, 255)
        MsgBox "✅ Welcome, Agent " & agentNum & "!" & vbCrLf & _
               "Session active for 15 minutes.", vbInformation, "SAMCIOUS"
    End If
End Sub

Private Function RequireAuth() As Integer
    ' Returns agent number if authenticated, 0 otherwise
    Dim ws As Worksheet: Set ws = ActiveSheet
    If Left(ws.Name, 6) <> "AGENT_" Then
        MsgBox "Please navigate to your Agent Dashboard first.", vbExclamation
        RequireAuth = 0: Exit Function
    End If
    Dim n As Integer: n = CInt(Mid(ws.Name, 7))
    If Not modV3AutoLock.IsAgentUnlocked(n) Then
        MsgBox "Dashboard is locked. Click UNLOCK and enter your code.", _
               vbExclamation, "SAMCIOUS — Access Denied"
        RequireAuth = 0
    Else
        RequireAuth = n
    End If
End Function

' ── REGISTER NEW CUSTOMER ─────────────────────────────────────────────────────
Public Sub RegisterCustomer()
    Dim agentNum As Integer: agentNum = RequireAuth()
    If agentNum = 0 Then Exit Sub

    Dim ws As Worksheet: Set ws = ActiveSheet

    ' Read from agent dashboard input cells
    Dim fullName As String: fullName = Trim(CStr(ws.Cells(9, 3).Value))
    Dim phone    As String: phone    = Trim(CStr(ws.Cells(9, 7).Value))
    Dim dob      As String: dob      = Trim(CStr(ws.Cells(10, 3).Value))
    Dim idType   As String: idType   = Trim(CStr(ws.Cells(10, 7).Value))
    Dim idNum    As String: idNum    = Trim(CStr(ws.Cells(10, 11).Value))
    Dim address  As String: address  = Trim(CStr(ws.Cells(11, 3).Value))
    Dim kinName  As String: kinName  = Trim(CStr(ws.Cells(11, 7).Value))
    Dim kinPhone As String: kinPhone = Trim(CStr(ws.Cells(11, 11).Value))

    If fullName = "" Or phone = "" Then
        MsgBox "Full Name and Phone are required.", vbExclamation, "SAMCIOUS"
        Exit Sub
    End If

    ' Check duplicate by phone
    Dim memWS As Worksheet: Set memWS = Sheets("Members")
    Dim r As Long
    For r = 4 To 1003
        If Trim(CStr(memWS.Cells(r, 5).Value)) = phone Then
            MsgBox "⚠ Phone number already registered!" & vbCrLf & _
                   "Name: " & memWS.Cells(r, 2).Value & vbCrLf & _
                   "Account: " & memWS.Cells(r, 1).Value, vbExclamation, "Duplicate Detected"
            Exit Sub
        End If
    Next r

    ' Generate unique account number
    Dim accNum As String: accNum = GenerateAccNo()

    ' Write to Members sheet
    Dim nRow As Long: nRow = 4
    Do While memWS.Cells(nRow, 1).Value <> "": nRow = nRow + 1: Loop

    With memWS
        .Cells(nRow, 1).Value  = accNum
        .Cells(nRow, 2).Value  = fullName
        .Cells(nRow, 3).Value  = dob
        .Cells(nRow, 4).Value  = address
        .Cells(nRow, 5).Value  = phone
        .Cells(nRow, 6).Value  = idType
        .Cells(nRow, 7).Value  = idNum
        .Cells(nRow, 8).Value  = kinName
        .Cells(nRow, 9).Value  = kinPhone
        .Cells(nRow, 10).Value = "Agent " & agentNum
        .Cells(nRow, 11).Value = Now()
        .Cells(nRow, 12).Value = "Pending KYC"
    End With

    ' Log to AGENT_DATABASE
    Call WriteAgentDB(Now(), "Agent " & agentNum, fullName, accNum, phone,
                      "Account Opening", 0, 0, 0, "Active", "", "", "")

    ' Clear input cells
    ws.Cells(9, 3).Value = ""
    ws.Cells(9, 7).Value = ""
    ws.Cells(9, 11).Value = accNum  ' Show generated account number
    ws.Cells(10, 3).Value = ""
    ws.Cells(10, 7).Value = ""
    ws.Cells(10, 11).Value = ""
    ws.Cells(11, 3).Value = ""
    ws.Cells(11, 7).Value = ""
    ws.Cells(11, 11).Value = ""

    Call modV3Admin.WriteAuditV3("REGISTRATION", "Acc:" & accNum & " | " & fullName, _
                                  "AGENT_" & agentNum, "SUCCESS")
    MsgBox "✅ Customer Registered!" & vbCrLf & vbCrLf & _
           "Name: " & fullName & vbCrLf & _
           "Account No: " & accNum & vbCrLf & _
           "Phone: " & phone, vbInformation, "SAMCIOUS — Registration"
End Sub

Private Function GenerateAccNo() As String
    Dim memWS As Worksheet: Set memWS = Sheets("Members")
    Dim accNum As String
    Dim isUnique As Boolean
    Do
        accNum = "30" & Format(Int(Rnd() * 99999999) + 10000000, "00000000")
        isUnique = True
        Dim r As Long
        For r = 4 To 1003
            If CStr(memWS.Cells(r, 1).Value) = accNum Then
                isUnique = False: Exit For
            End If
        Next r
    Loop Until isUnique
    GenerateAccNo = accNum
End Function

' ── SAVINGS DEPOSIT ───────────────────────────────────────────────────────────
Public Sub RecordSavings()
    Dim agentNum As Integer: agentNum = RequireAuth()
    If agentNum = 0 Then Exit Sub
    Dim ws As Worksheet: Set ws = ActiveSheet

    Dim accNo  As String: accNo  = Trim(CStr(ws.Cells(14, 3).Value))
    Dim txnType As String: txnType = Trim(CStr(ws.Cells(14, 7).Value))
    Dim amt    As String: amt    = Trim(CStr(ws.Cells(14, 9).Value))
    Dim notes  As String: notes  = Trim(CStr(ws.Cells(15, 9).Value))

    If accNo = "" Then MsgBox "Enter Account Number.", vbExclamation: Exit Sub
    If txnType = "" Then MsgBox "Select Transaction Type (Savings Deposit or Withdrawal).", vbExclamation: Exit Sub
    If Not IsNumeric(amt) Or CDbl(amt) <= 0 Then MsgBox "Enter a valid amount.", vbExclamation: Exit Sub

    ' Find member
    Dim memWS As Worksheet: Set memWS = Sheets("Members")
    Dim mRow As Long: mRow = FindMemberRow(accNo)
    If mRow = 0 Then
        MsgBox "Account not found: " & accNo, vbCritical, "SAMCIOUS"
        Exit Sub
    End If
    Dim custName As String: custName = memWS.Cells(mRow, 2).Value
    Dim phone    As String: phone    = memWS.Cells(mRow, 5).Value

    Dim dbl_amt As Double: dbl_amt = CDbl(amt)

    ' For withdrawals, check balance
    If txnType = "Withdrawal" Then
        Dim bal As Double: bal = GetBalance(accNo)
        If dbl_amt > bal Then
            MsgBox "Insufficient balance." & vbCrLf & "Available: GHS " & _
                   Format(bal, "#,##0.00"), vbExclamation: Exit Sub
        End If
    End If

    ' Write to Transactions
    Dim trxWS As Worksheet: Set trxWS = Sheets("Transactions")
    Dim refNo As String: refNo = IIf(txnType = "Withdrawal", "WDR", "DEP") & _
                                  Format(Now(), "YYMMDDHHmmSS")
    Dim tRow As Long: tRow = 4
    Do While trxWS.Cells(tRow, 1).Value <> "": tRow = tRow + 1: Loop
    With trxWS
        .Cells(tRow, 1).Value  = refNo
        .Cells(tRow, 2).Value  = Now()
        .Cells(tRow, 3).Value  = custName
        .Cells(tRow, 4).Value  = accNo
        .Cells(tRow, 5).Value  = txnType
        .Cells(tRow, 6).Value  = dbl_amt
        .Cells(tRow, 10).Value = "Agent " & agentNum
        .Cells(tRow, 12).Value = "Confirmed"
    End With

    ' Log to AGENT_DATABASE
    Call WriteAgentDB(Now(), "Agent " & agentNum, custName, accNo, phone,
                      txnType, dbl_amt, 0, 0, "Confirmed", notes, refNo, "")

    ' Clear inputs
    ws.Cells(14, 3).Value = ""
    ws.Cells(14, 7).Value = ""
    ws.Cells(14, 9).Value = ""
    ws.Cells(15, 3).Value = ""
    ws.Cells(15, 5).Value = ""
    ws.Cells(15, 9).Value = ""

    Call modV3Admin.WriteAuditV3(UCase(txnType), "Acc:" & accNo & " GHS " & _
                                  Format(dbl_amt, "#,##0.00"), "AGENT_" & agentNum, "SUCCESS")

    Dim emoji As String: emoji = IIf(txnType = "Withdrawal", "🏧", "💰")
    MsgBox emoji & " " & txnType & " Recorded!" & vbCrLf & vbCrLf & _
           "Customer: " & custName & vbCrLf & _
           "Amount: GHS " & Format(dbl_amt, "#,##0.00") & vbCrLf & _
           "Reference: " & refNo, vbInformation, "SAMCIOUS"
End Sub

' ── LOAN REQUEST ─────────────────────────────────────────────────────────────
Public Sub SubmitLoanRequest()
    Dim agentNum As Integer: agentNum = RequireAuth()
    If agentNum = 0 Then Exit Sub
    Dim ws As Worksheet: Set ws = ActiveSheet

    Dim accNo    As String: accNo    = Trim(CStr(ws.Cells(18, 3).Value))
    Dim loanAmt  As String: loanAmt  = Trim(CStr(ws.Cells(18, 9).Value))
    Dim rateStr  As String: rateStr  = Trim(CStr(ws.Cells(18, 11).Value))
    Dim purpose  As String: purpose  = Trim(CStr(ws.Cells(19, 5).Value))
    Dim tenure   As String: tenure   = Trim(CStr(ws.Cells(19, 7).Value))

    If accNo = "" Then MsgBox "Enter Account Number.", vbExclamation: Exit Sub
    If Not IsNumeric(loanAmt) Or CDbl(loanAmt) <= 0 Then
        MsgBox "Enter a valid loan amount.", vbExclamation: Exit Sub
    End If

    Dim mRow As Long: mRow = FindMemberRow(accNo)
    If mRow = 0 Then MsgBox "Account not found: " & accNo, vbCritical: Exit Sub

    Dim memWS As Worksheet: Set memWS = Sheets("Members")
    Dim custName As String: custName = memWS.Cells(mRow, 2).Value
    Dim phone    As String: phone    = memWS.Cells(mRow, 5).Value

    ' Parse interest rate
    Dim rate As Double: rate = 0
    Dim rateNum As String
    rateNum = rateStr
    ' Extract numeric part from rate string like "Flat 20%"
    Dim parts() As String: parts = Split(rateStr, " ")
    Dim p As Variant
    For Each p In parts
        Dim cleaned As String: cleaned = Replace(Replace(CStr(p), "%", ""), ",", "")
        If IsNumeric(cleaned) Then rate = CDbl(cleaned) / 100: Exit For
    Next p

    Dim dblAmt As Double:   dblAmt   = CDbl(loanAmt)
    Dim interest As Double: interest = dblAmt * rate
    Dim totalPay As Double: totalPay = dblAmt + interest

    ' Max loan check (5x savings)
    Dim savBal As Double: savBal = GetBalance(accNo)
    If dblAmt > savBal * 5 Then
        MsgBox "⚠ Loan exceeds maximum allowed (5× savings balance)." & vbCrLf & _
               "Max: GHS " & Format(savBal * 5, "#,##0.00"), vbExclamation
        Exit Sub
    End If

    ' Write to Pending_Loans
    Dim pendWS As Worksheet: Set pendWS = Sheets("Pending_Loans")
    Dim reqID  As String: reqID = "LOAN" & Format(Now(), "YYMMDDHHmmSS")
    Dim nRow   As Long: nRow = 4
    Do While pendWS.Cells(nRow, 1).Value <> "": nRow = nRow + 1: Loop
    With pendWS
        .Cells(nRow, 1).Value  = reqID
        .Cells(nRow, 2).Value  = custName
        .Cells(nRow, 3).Value  = accNo
        .Cells(nRow, 4).Value  = Now()
        .Cells(nRow, 5).Value  = "Agent " & agentNum
        .Cells(nRow, 6).Value  = dblAmt
        .Cells(nRow, 7).Value  = purpose
        .Cells(nRow, 8).Value  = rateStr
        .Cells(nRow, 9).Value  = totalPay
        .Cells(nRow, 10).Value = "Pending"
    End With

    ' Log to AGENT_DATABASE with Pending status
    Call WriteAgentDB(Now(), "Agent " & agentNum, custName, accNo, phone,
                      "Loan Request", dblAmt, rate, totalPay, "Pending", purpose, reqID, "")

    ' Clear loan input cells
    ws.Cells(18, 3).Value = ""
    ws.Cells(18, 5).Value = ""
    ws.Cells(18, 7).Value = ""
    ws.Cells(18, 9).Value = ""
    ws.Cells(18, 11).Value = ""
    ws.Cells(19, 3).Value = ""
    ws.Cells(19, 5).Value = ""
    ws.Cells(19, 7).Value = ""

    Call modV3Admin.WriteAuditV3("LOAN REQUEST", "Acc:" & accNo & " GHS " & _
                                  Format(dblAmt, "#,##0.00") & " | " & reqID, _
                                  "AGENT_" & agentNum, "SUCCESS")
    MsgBox "✅ Loan Request Submitted!" & vbCrLf & vbCrLf & _
           "Customer: " & custName & vbCrLf & _
           "Amount: GHS " & Format(dblAmt, "#,##0.00") & vbCrLf & _
           "Interest: GHS " & Format(interest, "#,##0.00") & vbCrLf & _
           "Total Payable: GHS " & Format(totalPay, "#,##0.00") & vbCrLf & vbCrLf & _
           "Request ID: " & reqID & vbCrLf & _
           "⏳ Awaiting Manager approval.", vbInformation, "SAMCIOUS — Loan Submitted"
End Sub

' ── HELPER: Write to AGENT_DATABASE ─────────────────────────────────────────
Public Sub WriteAgentDB(ts As Date, agent As String, custName As String, _
                         accNo As String, phone As String, txnType As String, _
                         amt As Double, intRate As Double, totalPay As Double, _
                         status As String, reason As String, loanID As String, _
                         approvedBy As String)
    On Error Resume Next
    Dim agWS As Worksheet: Set agWS = Sheets("AGENT_DATABASE")
    agWS.Visible = xlSheetVisible
    Dim nRow As Long: nRow = agWS.Cells(agWS.Rows.Count, 1).End(xlUp).Row + 1
    If nRow < 2 Then nRow = 2
    With agWS
        .Cells(nRow, 1).Value  = ts
        .Cells(nRow, 2).Value  = agent
        .Cells(nRow, 3).Value  = custName
        .Cells(nRow, 4).Value  = accNo
        .Cells(nRow, 5).Value  = phone
        .Cells(nRow, 6).Value  = txnType
        .Cells(nRow, 7).Value  = amt
        .Cells(nRow, 8).Value  = intRate
        .Cells(nRow, 9).Value  = totalPay
        .Cells(nRow, 10).Value = status
        .Cells(nRow, 11).Value = reason
        .Cells(nRow, 12).Value = loanID
        .Cells(nRow, 13).Value = approvedBy
    End With
    agWS.Visible = xlSheetVeryHidden
End Sub

Private Function FindMemberRow(accountNo As String) As Long
    Dim ws As Worksheet: Set ws = Sheets("Members")
    Dim r As Long
    For r = 4 To 1003
        If CStr(ws.Cells(r, 1).Value) = accountNo Then
            FindMemberRow = r: Exit Function
        End If
    Next r
    FindMemberRow = 0
End Function

Private Function GetBalance(accountNo As String) As Double
    On Error Resume Next
    Dim trxWS As Worksheet: Set trxWS = Sheets("Transactions")
    Dim deps As Double: deps = 0
    Dim wdrs As Double: wdrs = 0
    Dim r As Long
    For r = 4 To 5003
        If CStr(trxWS.Cells(r, 4).Value) = accountNo Then
            If trxWS.Cells(r, 5).Value = "Savings Deposit" Then
                deps = deps + CDbl(trxWS.Cells(r, 6).Value)
            ElseIf trxWS.Cells(r, 5).Value = "Withdrawal" Then
                wdrs = wdrs + CDbl(trxWS.Cells(r, 6).Value)
            End If
        End If
        If trxWS.Cells(r, 1).Value = "" And r > 10 Then Exit For
    Next r
    GetBalance = deps - wdrs
End Function

' ── LOOK UP MEMBER (for auto-fill) ───────────────────────────────────────────
Public Sub LookupMember()
    Dim agentNum As Integer: agentNum = RequireAuth()
    If agentNum = 0 Then Exit Sub
    Dim ws As Worksheet: Set ws = ActiveSheet

    Dim accNo As String: accNo = Trim(InputBox("Enter Account Number to look up:", "Member Lookup"))
    If accNo = "" Then Exit Sub

    Dim mRow As Long: mRow = FindMemberRow(accNo)
    If mRow = 0 Then MsgBox "Account not found: " & accNo, vbCritical: Exit Sub

    Dim memWS As Worksheet: Set memWS = Sheets("Members")
    Dim bal As Double: bal = GetBalance(accNo)

    MsgBox "👤 Member Found!" & vbCrLf & vbCrLf & _
           "Account: " & accNo & vbCrLf & _
           "Name: " & memWS.Cells(mRow, 2).Value & vbCrLf & _
           "Phone: " & memWS.Cells(mRow, 5).Value & vbCrLf & _
           "Address: " & memWS.Cells(mRow, 4).Value & vbCrLf & _
           "Balance: GHS " & Format(bal, "#,##0.00") & vbCrLf & _
           "Status: " & memWS.Cells(mRow, 12).Value, vbInformation, "SAMCIOUS"
End Sub


' ═══════════════════════════════════════════════════════════════════════════════
' MODULE E — Name module: modV3Manager
' Manager Dashboard Actions: Approve/Reject Loans, View Reports, Archive
' ═══════════════════════════════════════════════════════════════════════════════
Option Explicit

Public Sub ApproveLoanV3()
    If Not modV3Admin.IsManager() Then Exit Sub

    Dim reqID As String
    reqID = Trim(InputBox("Enter Loan Request ID to APPROVE:" & vbCrLf & _
                          "(e.g. LOAN2406121530)", "Approve Loan"))
    If reqID = "" Then Exit Sub

    Dim pendWS As Worksheet: Set pendWS = Sheets("Pending_Loans")
    Dim loanWS As Worksheet: Set loanWS = Sheets("Loans")
    Dim trxWS  As Worksheet: Set trxWS  = Sheets("Transactions")
    Dim memWS  As Worksheet: Set memWS  = Sheets("Members")

    ' Find request
    Dim reqRow As Long: reqRow = 0
    Dim r As Long
    For r = 4 To 503
        If CStr(pendWS.Cells(r, 1).Value) = reqID Then reqRow = r: Exit For
    Next r
    If reqRow = 0 Then MsgBox "Request not found: " & reqID, vbCritical: Exit Sub
    If pendWS.Cells(reqRow, 10).Value <> "Pending" Then
        MsgBox "Already processed: " & pendWS.Cells(reqRow, 10).Value, vbExclamation
        Exit Sub
    End If

    Dim custName As String: custName = pendWS.Cells(reqRow, 2).Value
    Dim accNo    As String: accNo    = pendWS.Cells(reqRow, 3).Value
    Dim loanAmt  As Double: loanAmt  = CDbl(pendWS.Cells(reqRow, 6).Value)
    Dim procFee  As Double: procFee  = loanAmt * 0.02
    Dim netAmt   As Double: netAmt   = loanAmt - procFee
    Dim rateStr  As String: rateStr  = pendWS.Cells(reqRow, 8).Value
    Dim totalPay As Double: totalPay = CDbl(pendWS.Cells(reqRow, 9).Value)

    Dim cf As Integer
    cf = MsgBox("APPROVE LOAN?" & vbCrLf & vbCrLf & _
                "Customer: " & custName & vbCrLf & _
                "Account:  " & accNo & vbCrLf & _
                "Loan Amount:    GHS " & Format(loanAmt, "#,##0.00") & vbCrLf & _
                "Processing Fee: GHS " & Format(procFee, "#,##0.00") & vbCrLf & _
                "Net to Credit:  GHS " & Format(netAmt, "#,##0.00") & vbCrLf & _
                "Interest Rate: " & rateStr & vbCrLf & _
                "Total Payable:  GHS " & Format(totalPay, "#,##0.00"), _
                vbYesNo + vbQuestion, "SAMCIOUS — Confirm Approval")
    If cf <> vbYes Then Exit Sub

    ' Update Pending_Loans
    pendWS.Cells(reqRow, 10).Value = "Approved"
    pendWS.Cells(reqRow, 11).Value = Now()
    pendWS.Cells(reqRow, 12).Value = Application.UserName

    ' Add to Loans register
    Dim lRow As Long: lRow = 4
    Do While loanWS.Cells(lRow, 1).Value <> "": lRow = lRow + 1: Loop
    With loanWS
        .Cells(lRow, 1).Value  = reqID
        .Cells(lRow, 2).Value  = custName
        .Cells(lRow, 3).Value  = accNo
        .Cells(lRow, 4).Value  = Now()
        .Cells(lRow, 5).Value  = loanAmt
        .Cells(lRow, 6).Value  = procFee
        .Cells(lRow, 7).Value  = netAmt
        .Cells(lRow, 8).Value  = rateStr
        .Cells(lRow, 9).Value  = 12   ' Default term
        .Cells(lRow, 11).Value = 0    ' Repaid so far
        .Cells(lRow, 13).Value = "Active"
    End With

    ' Record disbursement transaction
    Dim tRow As Long: tRow = 4
    Do While trxWS.Cells(tRow, 1).Value <> "": tRow = tRow + 1: Loop
    With trxWS
        .Cells(tRow, 1).Value  = "DISB" & Format(Now(), "YYMMDDHHmmSS")
        .Cells(tRow, 2).Value  = Now()
        .Cells(tRow, 3).Value  = custName
        .Cells(tRow, 4).Value  = accNo
        .Cells(tRow, 5).Value  = "Loan Disbursement"
        .Cells(tRow, 6).Value  = netAmt
        .Cells(tRow, 10).Value = Application.UserName
        .Cells(tRow, 12).Value = Application.UserName
    End With

    ' Update AGENT_DATABASE record
    Call UpdateAgentDBStatus(reqID, "Approved", Application.UserName)

    Call modV3Admin.WriteAuditV3("LOAN APPROVED", "Acc:" & accNo & " GHS " & _
                                  Format(netAmt, "#,##0.00") & " | " & reqID, _
                                  "Loans", "SUCCESS")
    MsgBox "✅ LOAN APPROVED & DISBURSED!" & vbCrLf & vbCrLf & _
           "GHS " & Format(netAmt, "#,##0.00") & " credited to " & custName, _
           vbInformation, "SAMCIOUS — Approved"
End Sub

Public Sub RejectLoanV3()
    If Not modV3Admin.IsManager() Then Exit Sub

    Dim reqID As String
    reqID = Trim(InputBox("Enter Loan Request ID to REJECT:", "Reject Loan"))
    If reqID = "" Then Exit Sub

    Dim reason As String
    reason = Trim(InputBox("Enter REASON for rejection (required):", "Rejection Reason"))
    If reason = "" Then MsgBox "Reason is required.", vbExclamation: Exit Sub

    Dim pendWS As Worksheet: Set pendWS = Sheets("Pending_Loans")
    Dim r As Long
    For r = 4 To 503
        If CStr(pendWS.Cells(r, 1).Value) = reqID Then
            If pendWS.Cells(r, 10).Value <> "Pending" Then
                MsgBox "Already processed.", vbExclamation: Exit Sub
            End If
            pendWS.Cells(r, 10).Value = "Rejected"
            pendWS.Cells(r, 11).Value = Now()
            pendWS.Cells(r, 12).Value = reason
            Call UpdateAgentDBStatus(reqID, "Rejected", reason)
            Call modV3Admin.WriteAuditV3("LOAN REJECTED", reqID & " | " & reason, "Pending_Loans", "WARNING")
            MsgBox "❌ Loan " & reqID & " REJECTED." & vbCrLf & "Reason: " & reason, vbInformation
            Exit Sub
        End If
    Next r
    MsgBox "Request not found: " & reqID, vbCritical
End Sub

Private Sub UpdateAgentDBStatus(loanID As String, status As String, byWho As String)
    On Error Resume Next
    Dim agWS As Worksheet: Set agWS = Sheets("AGENT_DATABASE")
    agWS.Visible = xlSheetVisible
    Dim r As Long
    For r = 2 To 10000
        If CStr(agWS.Cells(r, 12).Value) = loanID Then
            agWS.Cells(r, 10).Value = status
            agWS.Cells(r, 13).Value = byWho
        End If
        If agWS.Cells(r, 1).Value = "" And r > 5 Then Exit For
    Next r
    agWS.Visible = xlSheetVeryHidden
End Sub

Public Sub ArchiveFullyPaidLoans()
    If Not modV3Admin.IsManager() Then Exit Sub

    Dim loanWS As Worksheet: Set loanWS = Sheets("Loans")
    Dim arcWS  As Worksheet: Set arcWS  = Sheets("ARCHIVE")

    Dim arcRow As Long: arcRow = 6
    Do While arcWS.Cells(arcRow, 1).Value <> "": arcRow = arcRow + 1: Loop

    Dim count As Integer: count = 0
    Dim r As Long
    For r = 4 To 1003
        If CStr(loanWS.Cells(r, 13).Value) = "✅ Fully Paid" And _
           CStr(loanWS.Cells(r, 1).Value) <> "" Then
            ' Copy to archive
            With arcWS
                .Cells(arcRow, 1).Value  = loanWS.Cells(r, 1).Value   ' Loan ID
                .Cells(arcRow, 2).Value  = loanWS.Cells(r, 3).Value   ' Account No
                .Cells(arcRow, 3).Value  = loanWS.Cells(r, 2).Value   ' Customer
                .Cells(arcRow, 5).Value  = loanWS.Cells(r, 5).Value   ' Loan Amount
                .Cells(arcRow, 7).Value  = loanWS.Cells(r, 11).Value  ' Total Paid
                .Cells(arcRow, 8).Value  = loanWS.Cells(r, 4).Value   ' Date Issued
                .Cells(arcRow, 9).Value  = loanWS.Cells(r, 14).Value  ' Date Closed
            End With
            loanWS.Cells(r, 13).Value = "Archived"
            arcRow = arcRow + 1
            count = count + 1
        End If
    Next r

    MsgBox "✅ Archive complete. " & count & " loan(s) moved to ARCHIVE.", vbInformation, "SAMCIOUS"
    Call modV3Admin.WriteAuditV3("ARCHIVE", count & " loans archived", "ARCHIVE", "SUCCESS")
End Sub

Public Sub SearchArchive()
    Dim arcWS As Worksheet: Set arcWS = Sheets("ARCHIVE")
    Dim searchTerm As String
    searchTerm = Trim(InputBox("Search by Account Number OR Phone Number:", "Archive Search"))
    If searchTerm = "" Then Exit Sub

    Dim results As String: results = ""
    Dim r As Long
    For r = 6 To 5000
        If arcWS.Cells(r, 2).Value = searchTerm Or arcWS.Cells(r, 4).Value = searchTerm Then
            results = results & "Loan ID: " & arcWS.Cells(r, 1).Value & vbCrLf & _
                      "Customer: " & arcWS.Cells(r, 3).Value & vbCrLf & _
                      "Amount: GHS " & Format(arcWS.Cells(r, 5).Value, "#,##0.00") & vbCrLf & _
                      "Closed: " & Format(arcWS.Cells(r, 9).Value, "DD/MM/YYYY") & vbCrLf & _
                      "────────────────────────────────" & vbCrLf
        End If
        If arcWS.Cells(r, 1).Value = "" And r > 10 Then Exit For
    Next r

    If results = "" Then
        MsgBox "No records found for: " & searchTerm, vbInformation
    Else
        MsgBox "🗄 ARCHIVE RESULTS:" & vbCrLf & vbCrLf & results, vbInformation, "SAMCIOUS — Archive"
    End If
End Sub

Public Sub ViewAgentActivity()
    If Not modV3Admin.IsManager() Then Exit Sub
    Dim agWS As Worksheet
    agWS.Visible = xlSheetVisible
    Set agWS = Sheets("AGENT_DATABASE")
    agWS.Activate
End Sub

Public Sub RefreshManagerDashboard()
    Application.ScreenUpdating = False
    Application.Calculate
    Sheets("MANAGER_DASHBOARD").Activate
    Application.ScreenUpdating = True
    MsgBox "✅ Dashboard refreshed: " & Format(Now(), "DD/MM/YYYY HH:MM:SS"), _
           vbInformation, "SAMCIOUS"
End Sub


' ═══════════════════════════════════════════════════════════════════════════════
' MODULE F — Name module: modV3Buttons
' Create Buttons on All Dashboards (Run once after file opens)
' ═══════════════════════════════════════════════════════════════════════════════
Option Explicit

Public Sub BuildAllButtons()
    If Not modV3Admin.IsManager() Then Exit Sub
    Call BuildManagerButtons
    Dim i As Integer
    For i = 1 To 10
        Call BuildAgentButtons(i)
    Next i
    MsgBox "✅ All buttons created on all dashboards!", vbInformation, "SAMCIOUS"
End Sub

Private Sub BuildManagerButtons()
    On Error Resume Next
    Dim ws As Worksheet: Set ws = Sheets("MANAGER_DASHBOARD")

    ' Clear old shapes
    Dim shp As Shape
    For Each shp In ws.Shapes
        If shp.Type = msoFormControl Or shp.Type = msoOLEControlObject Then
            shp.Delete
        End If
    Next shp

    ' Button definitions: [caption, macro, left, top, width, height, bg_color]
    Dim btns As Variant
    btns = Array( _
        Array("✅ APPROVE LOAN",   "modV3Manager.ApproveLoanV3",       10,  50,  150, 28, RGB(30, 107, 58)), _
        Array("❌ REJECT LOAN",    "modV3Manager.RejectLoanV3",        170, 50,  140, 28, RGB(192, 57, 43)), _
        Array("🔄 REFRESH",        "modV3Manager.RefreshManagerDashboard", 320, 50, 100, 28, RGB(52, 73, 94)), _
        Array("🗄 ARCHIVE PAID",   "modV3Manager.ArchiveFullyPaidLoans",   430, 50, 130, 28, RGB(100, 100, 100)), _
        Array("🔍 SEARCH ARCHIVE", "modV3Manager.SearchArchive",       570, 50,  140, 28, RGB(41, 128, 185)), _
        Array("👤 ADD AGENT CODE", "modV3Admin.GenerateAgentCode",     10,  85,  150, 28, RGB(142, 68, 173)), _
        Array("✏ SET AGENT NAME",  "modV3Admin.SetAgentName",          170, 85,  140, 28, RGB(142, 68, 173)), _
        Array("▶ ACTIVATE AGENT", "modV3Admin.ActivateAgent",         320, 85,  120, 28, RGB(30, 107, 58)), _
        Array("⏸ DEACTIVATE",      "modV3Admin.DeactivateAgent",       450, 85,  120, 28, RGB(230, 126, 34)), _
        Array("🚫 REVOKE ACCESS",  "modV3Admin.RevokeAgentAccess",     580, 85,  140, 28, RGB(192, 57, 43)) _
    )

    Dim btn As Variant
    For Each btn In btns
        Dim b As Shape
        Set b = ws.Shapes.AddShape(msoShapeRoundedRectangle, _
                    btn(2), btn(3), btn(4), btn(5))
        With b
            .TextFrame.Characters.Text = btn(0)
            .TextFrame.Characters.Font.Name = "Arial"
            .TextFrame.Characters.Font.Size = 9
            .TextFrame.Characters.Font.Bold = True
            .TextFrame.Characters.Font.Color = RGB(255, 255, 255)
            .Fill.ForeColor.RGB = btn(6)
            .Line.Visible = msoFalse
            .TextFrame.HorizontalAlignment = xlHAlignCenter
            .OnAction = btn(1)
            .Adjustments.Item(1) = 0.25
        End With
    Next btn
End Sub

Private Sub BuildAgentButtons(agentNum As Integer)
    On Error Resume Next
    Dim ws As Worksheet: Set ws = Sheets("AGENT_" & agentNum)

    Dim shp As Shape
    For Each shp In ws.Shapes
        shp.Delete
    Next shp

    ' Button defs
    Dim btns As Variant
    btns = Array( _
        Array("🔓 UNLOCK DASHBOARD", "modV3Agent.UnlockDashboard",    10, 50, 160, 28, RGB(30, 107, 58)), _
        Array("🆕 REGISTER MEMBER",  "modV3Agent.RegisterCustomer",   180, 50, 150, 28, RGB(52, 73, 94)), _
        Array("💰 RECORD SAVINGS",   "modV3Agent.RecordSavings",      340, 50, 140, 28, RGB(30, 107, 58)), _
        Array("💼 SUBMIT LOAN",      "modV3Agent.SubmitLoanRequest",  490, 50, 130, 28, RGB(230, 126, 34)), _
        Array("🔍 MEMBER LOOKUP",    "modV3Agent.LookupMember",       630, 50, 130, 28, RGB(41, 128, 185)) _
    )

    Dim btn As Variant
    For Each btn In btns
        Dim b As Shape
        Set b = ws.Shapes.AddShape(msoShapeRoundedRectangle, _
                    btn(2), btn(3), btn(4), btn(5))
        With b
            .TextFrame.Characters.Text = btn(0)
            .TextFrame.Characters.Font.Name = "Arial"
            .TextFrame.Characters.Font.Size = 9
            .TextFrame.Characters.Font.Bold = True
            .TextFrame.Characters.Font.Color = RGB(255, 255, 255)
            .Fill.ForeColor.RGB = btn(6)
            .Line.Visible = msoFalse
            .TextFrame.HorizontalAlignment = xlHAlignCenter
            .OnAction = btn(1)
            .Adjustments.Item(1) = 0.25
        End With
    Next btn
End Sub


' ═══════════════════════════════════════════════════════════════════════════════
' MODULE G — Name module: modV3Reports
' Manager Reports: Daily Summary, Agent Performance
' ═══════════════════════════════════════════════════════════════════════════════
Option Explicit

Public Sub DailySummaryReport()
    If Not modV3Admin.IsManager() Then Exit Sub

    Dim agWS As Worksheet
    agWS.Visible = xlSheetVisible
    Set agWS = Sheets("AGENT_DATABASE")
    agWS.Visible = xlSheetVeryHidden

    Dim todayStr As String: todayStr = Format(Date, "DD/MM/YYYY")
    Dim totalSav As Double, totalLoans As Double, totalWdr As Double
    Dim totalTxns As Long
    Dim r As Long

    agWS.Visible = xlSheetVisible
    For r = 2 To 50000
        If agWS.Cells(r, 1).Value = "" And r > 5 Then Exit For
        If Format(CDate(agWS.Cells(r, 1).Value), "DD/MM/YYYY") = todayStr Then
            Select Case agWS.Cells(r, 6).Value
                Case "Savings Deposit":   totalSav   = totalSav   + CDbl(agWS.Cells(r, 7).Value)
                Case "Loan Disbursement": totalLoans = totalLoans + CDbl(agWS.Cells(r, 7).Value)
                Case "Withdrawal":        totalWdr   = totalWdr   + CDbl(agWS.Cells(r, 7).Value)
            End Select
            totalTxns = totalTxns + 1
        End If
    Next r
    agWS.Visible = xlSheetVeryHidden

    MsgBox "📊 DAILY SUMMARY REPORT" & vbCrLf & _
           "Date: " & todayStr & vbCrLf & _
           "════════════════════════════════" & vbCrLf & _
           "💰 Total Savings:        GHS " & Format(totalSav, "#,##0.00") & vbCrLf & _
           "💼 Total Loans Disbursed: GHS " & Format(totalLoans, "#,##0.00") & vbCrLf & _
           "🏧 Total Withdrawals:     GHS " & Format(totalWdr, "#,##0.00") & vbCrLf & _
           "📈 Net Position:          GHS " & Format(totalSav - totalLoans - totalWdr, "#,##0.00") & vbCrLf & _
           "📋 Total Transactions:    " & totalTxns, _
           vbInformation, "SAMCIOUS — Daily Report"
End Sub


' ═══════════════════════════════════════════════════════════════════════════════
' MODULE H — Name module: modV3SMS
' SMS Notifications via Hubtel (Ghana) — configure in Config sheet
' ═══════════════════════════════════════════════════════════════════════════════
Option Explicit

Private Function GetSMSCred(key As String) As String
    On Error Resume Next
    Dim ws As Worksheet: Set ws = Sheets("Config")
    Select Case key
        Case "id":     GetSMSCred = Trim(ws.Range("B11").Value)
        Case "secret": GetSMSCred = Trim(ws.Range("B12").Value)
        Case "sender": GetSMSCred = Trim(ws.Range("B13").Value)
    End Select
End Function

Public Function SendSMS_v3(toPhone As String, msg As String) As Boolean
    On Error GoTo err_
    If GetSMSCred("id") = "" Then SendSMS_v3 = False: Exit Function
    Dim phone As String: phone = toPhone
    If Left(phone, 1) = "0" Then phone = "+233" & Mid(phone, 2)
    If Left(phone, 1) <> "+" Then phone = "+233" & phone
    Dim http As Object
    Set http = CreateObject("MSXML2.XMLHTTP")
    Dim url As String
    url = "https://smsc.hubtel.com/v1/messages/send" & _
          "?clientsecret=" & GetSMSCred("secret") & _
          "&clientid=" & GetSMSCred("id") & _
          "&from=" & GetSMSCred("sender") & _
          "&to=" & phone & _
          "&content=" & WorksheetFunction.EncodeURL(msg)
    http.Open "GET", url, False
    http.Send
    SendSMS_v3 = (http.Status = 200)
    Exit Function
err_: SendSMS_v3 = False
End Function

Public Sub TestSMS_v3()
    If Not modV3Admin.IsManager() Then Exit Sub
    Dim ph As String: ph = InputBox("Phone to test:", "SMS Test")
    If ph = "" Then Exit Sub
    If SendSMS_v3(ph, "SAMCIOUS MFI v3: Test OK! " & Format(Now(), "HH:MM")) Then
        MsgBox "✅ SMS sent!", vbInformation
    Else
        MsgBox "❌ Failed. Configure Hubtel credentials in Config sheet (B11-B13).", vbCritical
    End If
End Sub

' ═══════════════════════════════════════════════════════════════════════════════
' END OF SAMCIOUS MFI v3 VBA PACKAGE
' ═══════════════════════════════════════════════════════════════════════════════
